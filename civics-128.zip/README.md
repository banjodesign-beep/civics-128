# Civics 128

Mobile study app for the 2025 USCIS naturalization civics test (128 questions, 20 asked, 12 correct to pass).

- **Practice 10**: ten questions, answer explained after each, weighted toward the ones you miss.
- **Full sample test**: 20 random questions from all 128, stops at 12 right or 9 wrong like the real interview.
- **Two answer modes**: multiple choice for learning, Interview mode (say it out loud, reveal, self-grade) for the real format.
- **All 128**: the full official list with every accepted answer, searchable.
- **Progress**: mastery by section, test history, most-missed list. Saved in the browser on your phone.

Source: USCIS form M-1778 (09/25), *128 Civics Questions and Answers (2025 version)*.

## Deploy (GitHub web UI + Netlify, no command line)

1. On github.com, create a new repository (for example `civics-128`).
2. Click **Add file → Upload files**, drag in `index.html` and this `README.md`, then **Commit changes**.
3. On app.netlify.com: **Add new site → Import an existing project → GitHub**, pick the repo.
4. Leave **Build command** empty and **Publish directory** empty (or `/`). Click **Deploy**.
5. On your phone, open the Netlify URL and use **Share → Add to Home Screen**.

Every later commit to the repo redeploys automatically.

## Keep these current

Questions 23, 29, 30, 38, 39, 57, 61 and 62 depend on who holds office. They are filled in for Colorado Springs (CO-5) as of October 19, 2026, and can be edited on the Progress screen. Check https://www.uscis.gov/citizenship/testupdates before your interview.
